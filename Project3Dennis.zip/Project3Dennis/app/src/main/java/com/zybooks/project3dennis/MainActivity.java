package com.zybooks.project3dennis;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 1;
    private final com.example.weightapp.WeightTrackerDbHelper dbHelper = new com.example.weightapp.WeightTrackerDbHelper(this);
    private GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridView);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_CODE);
        } else {
            // Permission already granted
            loadWeight();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                loadWeight();
            } else {
                // Permission denied
                // Continue without SMS functionality
                loadWeight();
            }
        }
    }

    private void loadWeight() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("weight", null, null, null, null, null, null);

        String[] fromColumns = {"item_name", "quantity"};
        int[] toViews = {R.id.itemName, R.id.quantity};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                R.layout.grid_item, cursor, fromColumns, toViews, 0);
        gridView.setAdapter(adapter);
    }
}